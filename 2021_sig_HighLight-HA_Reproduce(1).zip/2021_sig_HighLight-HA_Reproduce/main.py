from cProfile import label
from torchvision import transforms, utils
#加载DataLoader
from torch.utils.data import DataLoader
import torch
import trainset
import HAmodel
import MyLoss
import numpy as np
from renderers import LocalRenderer, RednerRenderer
# 测试数据集读取
# trainset.test_dataset ()
from PIL import ImageFile
import matplotlib.pyplot as plt
ImageFile.LOAD_TRUNCATED_IMAGES = True
Loss_list = []
BEST_ANSWERS = []

def adjust_learning_rate(optimizer, epoch):
   
    lr = 0.0002
    if epoch > 200:
        lr = 0.00016
    if epoch > 300:
        lr = 0.00012
    if epoch > 500:
        lr = 0.0001
    if epoch > 600:
        lr = 0.00007
    if epoch > 800:
        lr = 0.00003
    if epoch > 1400:
        lr = 0.00002

    for param_group in optimizer.param_groups:
        param_group['lr'] = lr
def adjust_learning_rate1(optimizer_adv1, epoch):
   
    lr = 0.0002
    if epoch > 200:
        lr = 0.00016
    if epoch > 300:
        lr = 0.00012
    if epoch > 500:
        lr = 0.0001
    if epoch > 600:
        lr = 0.00007
    if epoch > 800:
        lr = 0.00003
    if epoch > 1400:
        lr = 0.00002
 

    for param_group in optimizer_adv1.param_groups:
        param_group['lr'] = lr
def adjust_learning_rate2(optimizer_adv2, epoch):
   
    lr = 0.0002
    if epoch > 200:
        lr = 0.00016
    if epoch > 300:
        lr = 0.00012
    if epoch > 500:
        lr = 0.0001
    if epoch > 600:
        lr = 0.00007
    if epoch > 800:
        lr = 0.00003
    if epoch > 1400:
        lr = 0.00002
 

    for param_group in optimizer_adv2.param_groups:
        param_group['lr'] = lr
def adjust_learning_rate3(optimizer_adv3, epoch):
   
    lr = 0.0002
    if epoch > 10:
        lr = 0.00016
    if epoch > 200:
        lr = 0.00012
    if epoch > 400:
        lr = 0.0001
    if epoch > 700:
        lr = 0.00007
    if epoch > 1000:
        lr = 0.00003
    if epoch > 1400:
        lr = 0.00002
 

    for param_group in optimizer_adv3.param_groups:
        param_group['lr'] = lr

def adjust_learning_rate4(optimizer_adv4, epoch):
   
    #lr = args.lr * (0.1 ** (epoch))
    lr = 0.0002
    if epoch > 10:
        lr = 0.00016
    if epoch > 200:
        lr = 0.00012
    if epoch > 400:
        lr = 0.0001
    if epoch > 700:
        lr = 0.00007
    if epoch > 1000:
        lr = 0.00003
    if epoch > 1400:
        lr = 0.00002
 

    for param_group in optimizer_adv4.param_groups:
        param_group['lr'] = lr


# 主程序入口
if __name__ == '__main__':
    # 设置训练数据集的路径
    torch.cuda.set_device(7) #　指定gpu1
    root_dir = '/home/wyh/data'
    # 设置训练数据集的变换
    transform = transforms.Compose([
        transforms.ToTensor()])
    # 实例化训练数据集
    trainset = trainset.TrainSet(root_dir, transform)
    # 实例化训练数据集的加载器
    trainloader = DataLoader(trainset, batch_size=4, shuffle=True, num_workers=0)
    # 实例化模型
    model = HAmodel.HAmodel()
    # 加载训练过的模型参数
    # model.load_state_dict(torch.load('./model6.27.1pth'))
    # 将模型放入GPU
    model = model.cuda()
    # 实例化优化器
    optimizer = torch.optim.Adam(model.parameters(), lr=0.0002)
    # 实例化损失函数

    loss_renderer = LocalRenderer()

    loss_func = MyLoss.MyLoss(loss_renderer)

    adv_loss_func = MyLoss.AdvMyLoss()
    # 实例化对抗训练模型
    adversary1 = MyLoss.advModel()
    adversary2 = MyLoss.advModel2()
    # adversary3 = MyLoss.advModel()
    # adversary4 = MyLoss.advModel2()
    # 将模型放入GPU
    adversary1 = adversary1.cuda()
    adversary2 = adversary2.cuda()
    # adversary3 = adversary3.cuda()
    # adversary4 = adversary4.cuda()
    # 实例化优化器
    optimizer_adv1 = torch.optim.Adam(adversary1.parameters(), lr=0.0002)
    optimizer_adv2 = torch.optim.Adam(adversary2.parameters(), lr=0.0002)
    # optimizer_adv3 = torch.optim.Adam(adversary3.parameters(), lr=0.0002)
    # optimizer_adv4 = torch.optim.Adam(adversary4.parameters(), lr=0.0002)
    # 打印GPU占用比例
    print('GPU占用比例：', torch.cuda.memory_allocated() / torch.cuda.get_device_properties(0).total_memory)

    # 训练模型
    for epoch in range(4000):
        add=0
        
        for i, datas in enumerate(trainloader):
            # 获取输入数据
            inputs = datas[0]
            # 获取4种标签数据
            label1 = datas[1]
            label2 = datas[2]
            label3 = datas[3]
            label4 = datas[4]
            # 将数据放入GPU
            inputs = inputs.to('cuda')
            label1 = label1.to('cuda')
            label2 = label2.to('cuda')
            label3 = label3.to('cuda')
            label4 = label4.to('cuda')
            # 将数据放入模型
            output1, output2, output3, output4 = model(inputs)

            output1 = torch.clamp(output1, -1, 1)
            output2 = torch.clamp(output2, 0, 1)
            output3 = torch.clamp(output3, 0, 1)
            output4 = torch.clamp(output4, 0, 1)

            # 经过对抗训练，获取对抗训练后的输出
            output1_adv = adversary1(output1, label1)
            output4_adv = adversary2(output2, label2)
            # output3_adv = adversary3(output3, label3)
            # output44_adv = adversary4(output4, label4)
            # 计算损失
            # loss1 = loss_func(output1, label1)
            adv_loss1 = adv_loss_func(output1, label1,output1_adv)
            adv_loss2 = adv_loss_func(output2, label2,output4_adv)
            # adv_loss3 = adv_loss_func(output3, label3,output3_adv)
            # # loss4 = loss_func(output4, label4)
            # adv_loss4 = adv_loss_func(output4, label4,output44_adv)

            output = torch.cat((output1, output2, output3, output4), 1)
            # 将标签按照顺序拼接
            label = torch.cat((label1, label2, label3, label4), 1)

            loss_nor = loss_func(output,label)
            # 清空梯度
            optimizer.zero_grad()
            optimizer_adv1.zero_grad()
            optimizer_adv2.zero_grad()
            # optimizer_adv3.zero_grad()
            # optimizer_adv4.zero_grad()
            # 计算梯度
            # adv_loss = adv_loss1 + adv_loss2 + adv_loss3 + adv_loss4
            adv_loss = adv_loss1 + adv_loss2
            loss=adv_loss+ loss_nor
            add+=loss
            # 反向传播
            loss.backward()
            # 更新参数
            optimizer.step()
            optimizer_adv1.step()
            optimizer_adv2.step()
            # optimizer_adv3.step()
            # optimizer_adv4.step()
            # 打印训练信息
            if (i + 1) % 3 == 0:
                print('Epoch:', epoch, '| train loss: %.4f' % loss.item())
                # print('GPU占用比例：', torch.cuda.memory_allocated() / torch.cuda.get_device_properties(0).total_memory)
        print("model_i:",i)
        add=add.data.cpu().numpy()
        Loss_list.append(add/501)
        plt.cla()
        x1 = range(0, epoch+1)
        print(x1)
        y1 = Loss_list
        print(y1)
        # y1=y1
        plt.title('Train loss vs. epoches', fontsize=20)
        plt.plot(x1, y1, '.-')
        plt.xlabel('epoches', fontsize=20)
        plt.ylabel('Train loss', fontsize=20)
        plt.grid()
        plt.savefig("./Train_loss.jpg")
        plt.show()
        # adjust_learning_rate(optimizer,epoch)
        # adjust_learning_rate1(optimizer_adv1, epoch)
        # adjust_learning_rate2(optimizer_adv2, epoch)
        # adjust_learning_rate3(optimizer_adv3, epoch)
        # adjust_learning_rate4(optimizer_adv4, epoch)
        torch.save(model.state_dict(), './model7.3pth')
    # 保存模型
    