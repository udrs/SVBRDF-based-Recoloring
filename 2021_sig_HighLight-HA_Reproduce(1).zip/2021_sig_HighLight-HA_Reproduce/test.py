from cProfile import label
from torchvision import transforms, utils
#加载DataLoader
from torch.utils.data import DataLoader
import torch
import trainset
import HAmodel
import numpy as np
import matplotlib.pyplot as plt
from sklearn import metrics
from PIL import Image

# 测试生成的模型
# 设置训练数据集的路径
torch.cuda.set_device(3) #　指定gpu1
root_dir = '/home/wyh/datatest'
# 设置训练数据集的变换
transform = transforms.Compose([
    transforms.ToTensor()])
# 实例化训练数据集
testset = trainset.TrainSet(root_dir, transform)
# 实例化训练数据集的加载器
testloader = DataLoader(testset, batch_size=1, shuffle=True, num_workers=0)
# 实例化模型
model = HAmodel.HAmodel()
# 加载模型
model.load_state_dict(torch.load('/home/wyh/model6.27.1pth'))
# 将模型放入GPU
model = model.to('cuda')
# 定义测试集的标签
test_label1 = []
test_label2 = []
test_label3 = []
test_label4 = []
# 定义测试集的预测
test_predict1 = []
test_predict2 = []
test_predict3 = []
test_predict4 = []
n = 0
n1 = 0
n2 = 0
n3 = 0
n4 = 0
nn = 0.01
nm = 0.01

# 进行测试
for i, datas in enumerate(testloader):
    print('test:', i, 'images')
    fig = plt.figure(figsize=(8, 8))
    # 获取输入数据
    inputs = datas[0]

    # 获取4种标签数据
    label1 = datas[1]
    label2 = datas[2]
    label3 = datas[3]
    label4 = datas[4]
    # 将数据放入GPU
    inputs = inputs.to('cuda')
    label1 = label1.to('cuda')
    label2 = label2.to('cuda')
    label3 = label3.to('cuda')
    label4 = label4.to('cuda')
    # 将数据放入模型
    output1, output2, output3, output4 = model(inputs)
    # 计算测试集的标签
    test_label1.append(label1.cpu().detach().numpy())
    test_label2.append(label2.cpu().detach().numpy())
    test_label3.append(label3.cpu().detach().numpy())
    test_label4.append(label4.cpu().detach().numpy())
    # 计算测试集的预测
    test_predict1.append(output1.cpu().detach().numpy())
    test_predict2.append(output2.cpu().detach().numpy())
    test_predict3.append(output3.cpu().detach().numpy())
    test_predict4.append(output4.cpu().detach().numpy())
    # 打印进度
    # print('test:', i, 'images')
    # 当进度为10时，使用matplotlib绘制测试集的标签和预测到屏幕
    # if i  ==  20:
    test_label1_2draw = np.array(test_label1[i][0].transpose(1, 2, 0))
    test_label2_2draw = np.array(test_label2[i][0].transpose(1, 2, 0))
    test_label3_2draw = np.array(test_label3[i][0].transpose(1, 2, 0))
    test_label4_2draw = np.array(test_label4[i][0].transpose(1, 2, 0))
    test_predict1_2draw = np.array(test_predict1[i][0].transpose(1, 2, 0))
    test_predict2_2draw = np.array(test_predict2[i][0].transpose(1, 2, 0))
    test_predict3_2draw = np.array(test_predict3[i][0].transpose(1, 2, 0))
    test_predict4_2draw = np.array(test_predict4[i][0].transpose(1, 2, 0))
        # 查看测试集的标签数据形状
    test_label1_2draw = test_label1_2draw * 255
    test_label1_2draw = test_label1_2draw.astype(np.uint8)
    test_label2_2draw = test_label2_2draw * 255
    test_label2_2draw = test_label2_2draw.astype(np.uint8)
    test_label3_2draw = test_label3_2draw * 255
    test_label3_2draw = test_label3_2draw.astype(np.uint8)
    test_label4_2draw = test_label4_2draw * 255
    test_label4_2draw = test_label4_2draw.astype(np.uint8)
    test_predict1_2draw = test_predict1_2draw * 255
    test_predict1_2draw = test_predict1_2draw.astype(np.uint8)
    test_predict2_2draw = test_predict2_2draw * 255
    test_predict2_2draw = test_predict2_2draw.astype(np.uint8)
    test_predict3_2draw = test_predict3_2draw * 255
    test_predict3_2draw = test_predict3_2draw.astype(np.uint8)
    test_predict4_2draw = test_predict4_2draw * 255
    test_predict4_2draw = test_predict4_2draw.astype(np.uint8)
    # 将测试集的标签和预测分别绘制到屏幕，绘制到同一张图中
    plt.figure(1)
    plt.imshow(test_label1_2draw)
    plt.axis('off')
    plt.savefig("/home/wyh/render_result/render_lable_normal_30.jpg",bbox_inches='tight',dpi=fig.dpi,pad_inches=0.0)

    plt.figure(2)
    plt.imshow(test_label2_2draw)
    plt.axis('off')
    plt.savefig("/home/wyh/render_result/render_lable_diffuse_30.jpg",bbox_inches='tight',dpi=fig.dpi,pad_inches=0.0)

    plt.figure(3)
    plt.imshow(test_label3_2draw)
    plt.axis('off')
    plt.savefig("/home/wyh/render_result/render_lable_roughness_30.jpg",bbox_inches='tight',dpi=fig.dpi,pad_inches=0.0)

    plt.figure(4)
    plt.imshow(test_label4_2draw)
    plt.axis('off')
    plt.savefig("/home/wyh/render_result/render_lable_specular_30.jpg",bbox_inches='tight',dpi=fig.dpi,pad_inches=0.0)
        
        
    plt.figure(5)
    # plt.subplot(221)
    plt.imshow(test_predict1_2draw)
    plt.axis('off')
    plt.savefig("/home/wyh/render_result/render_test_normal_30.jpg",bbox_inches='tight',dpi=fig.dpi,pad_inches=0.0)


    plt.figure(6)
        # plt.subplot(222)
    plt.imshow(test_predict2_2draw)
    plt.axis('off')
    plt.savefig("/home/wyh/render_result/render_test_diffuse_30.jpg",bbox_inches='tight',dpi=fig.dpi,pad_inches=0.0)
        
    plt.figure(7)
        # plt.subplot(223)
    plt.imshow(test_predict3_2draw)
    plt.axis('off')
    plt.savefig("/home/wyh/render_result/render_test_roughness_30.jpg",bbox_inches='tight',dpi=fig.dpi,pad_inches=0.0)
        
    plt.figure(8)
        # plt.subplot(224)
    plt.imshow(test_predict4_2draw)
    plt.axis('off')
    plt.savefig("/home/wyh/render_result/render_test_specular_30.jpg",bbox_inches='tight',dpi=fig.dpi,pad_inches=0.0)
    
    print(shape(test_label1_2draw))
    print(shape(test_predict1_2draw))
    
    result1 = np.sqrt(metrics.mean_squared_error(test_predict1_2draw[0], test_label1_2draw[0]))+np.sqrt(metrics.mean_squared_error(test_predict1_2draw[1], test_label1_2draw[1]))+np.sqrt(metrics.mean_squared_error(test_predict1_2draw[2], test_label1_2draw[2]))*nm*nn
    
    result2 = np.sqrt(metrics.mean_squared_error(test_predict2_2draw[0], test_label2_2draw[0]))+np.sqrt(metrics.mean_squared_error(test_predict2_2draw[1], test_label2_2draw[1]))+np.sqrt(metrics.mean_squared_error(test_predict2_2draw[2], test_label2_2draw[2]))*nm*nn
   
    result3 = np.sqrt(metrics.mean_squared_error(test_predict3_2draw[0], test_label3_2draw[0]))+np.sqrt(metrics.mean_squared_error(test_predict3_2draw[1], test_label3_2draw[1]))+np.sqrt(metrics.mean_squared_error(test_predict3_2draw[2], test_label3_2draw[2]))*nm*nn
   
    result4 = np.sqrt(metrics.mean_squared_error(test_predict4_2draw[0], test_label4_2draw[0]))+np.sqrt(metrics.mean_squared_error(test_predict4_2draw[1], test_label4_2draw[1]))+np.sqrt(metrics.mean_squared_error(test_predict4_2draw[2], test_label4_2draw[2]))*nm*nn
 
    n=n+(result1+result2+result3+result4)
    n1=n1+result1
    n2=n2+result2
    n3=n3+result3
    n4=n4+result4
        # plt.show()
        # plt.savefig("test_specular.jpg")
print("1:",n1)
print("2:",n2)
print("3:",n3)
print("4:",n4)
print("render",n)