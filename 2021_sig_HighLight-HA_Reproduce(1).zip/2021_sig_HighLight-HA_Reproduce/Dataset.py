

from jittor.dataset.dataset import Dataset
from jittor import transform
import matplotlib.pyplot as plt
import os
from PIL import Image
import numpy as np

class TrainSet(Dataset):
    def __init__(self, root_dir, batch_size, shuffle=False, num_workers=0, transform=None):
        # super().__init__(root_dir,transform)
        super().__init__()
        self.root_dir=root_dir
        self.transform = transform
        self.shuffle=shuffle
        self.batch_size = batch_size
        self.imgs=os.listdir(root_dir)
        self.total_len = len(self.imgs)
        self.set_attrs(batch_size = self.batch_size, total_len = self.total_len, shuffle = self.shuffle)
    
    def __getitem__(self, idx):
        img_name = self.imgs[idx]
        img_path = os.path.join(self.root_dir,img_name)
        image = Image.open(img_path)
        image1 = image.crop((0, 0, image.width//5, image.height))
        image2 = image.crop((image.width//5, 0, image.width//5*2, image.height))
        image3 = image.crop((image.width//5*2, 0, image.width//5*3, image.height))
        image4 = image.crop((image.width//5*3, 0, image.width//5*4, image.height))
        image5 = image.crop((image.width//5*4, 0, image.width, image.height))
        images = [image1,image2,image3,image4,image5]
        if self.transform:
            images = [self.transform(image) for image in images]
        return images
def test_dataset():
    root_dir = "D:/BRDF/svbrdf/Data/Data_Deschaintre18/testBlended"
    transform_val = transform.Compose([
        transform.ToTensor()])
    trainloader = TrainSet(root_dir,4,transform_val)
    
    for i, datas in enumerate(trainloader):
        # 遍历datas并显示到屏幕上
        for data in datas:
            # 显示图片到屏幕上
            img = data[0].numpy()
            img = img.transpose(1, 2, 0)
            img = img * 255
            img = img.astype(np.uint8)
            plt.imshow(img)
            plt.show()

test_dataset()
# def wa():
#     # 定义训练数据集的路径
#     root_dir = './train_part'
#     # 定义训练数据集的变换
#     transform = transforms.Compose([
#         transforms.ToTensor()])
#     # 实例化训练数据集
#     trainset = TrainSet(root_dir, transform)
#     # 输出数据集的大小
#     print(len(trainset))
#     # 实例化训练数据集的加载器
#     trainloader = DataLoader(trainset, batch_size=4, shuffle=True, num_workers=0)
#     # 循环训练数据集
    # for i, datas in enumerate(trainloader):
    #     # 遍历datas并显示到屏幕上
    #     for data in datas:
    #         # 显示图片到屏幕上
    #         img = data[0].numpy()
    #         img = img.transpose(1, 2, 0)
    #         img = img * 255
    #         img = img.astype(np.uint8)
    #         plt.imshow(img)
    #         plt.show()
